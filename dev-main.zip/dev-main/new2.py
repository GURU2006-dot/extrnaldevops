from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

# Open Edge browser
driver = webdriver.Edge()

# Open Facebook
driver.get("https://www.facebook.com")

# Maximize window
driver.maximize_window()

# Wait object
wait = WebDriverWait(driver, 20)

# Wait for email field
email = wait.until(
    EC.presence_of_element_located((By.NAME, "email"))
)

# Enter email
email.send_keys("9392387365")

# Wait for password field
password = wait.until(
    EC.presence_of_element_located((By.NAME, "pass"))
)

# Enter password
password.send_keys("Harish@427474")




# Wait after login
time.sleep(10)

# Close browser
driver.quit()
