from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time

# Open Microsoft Edge browser
driver = webdriver.Edge()

# Open Google homepage
driver.get("https://www.google.com")

# Maximize browser window
driver.maximize_window()

# Wait for page load
time.sleep(2)

# Locate Google search box
search_box = driver.find_element(By.NAME, "q")

# Enter search text
search_box.send_keys("Selenium WebDriver")

# Press Enter key
search_box.send_keys(Keys.RETURN)

# Wait for search results
time.sleep(5)

# Print page title
print("Page Title:", driver.title)

# Close browser
driver.quit()
