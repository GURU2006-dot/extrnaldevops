"""Example package for CI demonstration."""

from .calculator import add, divide

__all__ = ["add", "divide"]
