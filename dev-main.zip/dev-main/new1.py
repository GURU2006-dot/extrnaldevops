from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# Open Microsoft Edge browser
driver = webdriver.Edge()

# Open Google homepage
driver.get("https://www.google.com")

# Wait for page to load
time.sleep(2)

# Locate search box element
search_box = driver.find_element(By.NAME, "q")

# Print element details
print("Tag Name:", search_box.tag_name)

# Close browser
driver.quit()
